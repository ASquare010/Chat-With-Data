
class FieldMetadata(BaseModel):
    """Clickhouse Field metadata model."""

    data_type: str
    description: Optional[str] = None


class TableMetadata(BaseModel):
    """Clickhouse table Metadata model."""

    table_name: str
    fields: Dict[str, FieldMetadata] = {}  # {col_name: FieldMetadata_obj}}


class SchemaMetadata(BaseModel):
    """Clickhouse Schema Metadata  model."""

    schema_name: str
    entities: Dict[str, TableMetadata] | List[TableMetadata]
    schema_doc: Optional[str] = None

